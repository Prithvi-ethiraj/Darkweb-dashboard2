import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../context/AuthContext';
import axios from 'axios';
import ReportCard from './components/ReportCard';
import GenerateReportModal from './components/GenerateReportModal';
import './Reports.css';

const Reports = () => {
  const { currentUser } = useAuth();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [reportTypes] = useState([
    { id: 1, name: 'Daily Summary', template: 'summary' },
    { id: 2, name: 'Data Analysis', template: 'analysis' },
    { id: 3, name: 'User Activity', template: 'activity' },
    { id: 4, name: 'System Health', template: 'health' },
  ]);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await axios.get('/api/reports', {
          headers: { Authorization: `Bearer ${currentUser.token}` }
        });
        setReports(res.data);
      } catch (err) {
        console.error('Error fetching reports:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchReports();
  }, [currentUser]);

  const handleGenerateReport = async (reportData) => {
    try {
      const res = await axios.post('/api/reports/generate', reportData, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setReports([res.data, ...reports]);
      setShowModal(false);
    } catch (err) {
      console.error('Error generating report:', err);
    }
  };

  const handleDeleteReport = async (id) => {
    try {
      await axios.delete(`/api/reports/${id}`, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setReports(reports.filter(report => report._id !== id));
    } catch (err) {
      console.error('Error deleting report:', err);
    }
  };

  return (
    <div className="reports-container">
      <div className="reports-header">
        <h1>Reports</h1>
        <button 
          className="generate-report-btn"
          onClick={() => setShowModal(true)}
        >
          + Generate Report
        </button>
      </div>

      {loading ? (
        <div className="loading-spinner"></div>
      ) : reports.length === 0 ? (
        <div className="empty-state">
          <p>No reports available. Generate your first report.</p>
        </div>
      ) : (
        <div className="reports-list">
          {reports.map(report => (
            <ReportCard
              key={report._id}
              report={report}
              onDelete={handleDeleteReport}
            />
          ))}
        </div>
      )}

      <GenerateReportModal
        show={showModal}
        onClose={() => setShowModal(false)}
        onSubmit={handleGenerateReport}
        reportTypes={reportTypes}
      />
    </div>
  );
};

export default Reports;
