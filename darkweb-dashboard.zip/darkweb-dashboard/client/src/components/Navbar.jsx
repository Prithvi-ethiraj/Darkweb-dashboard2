import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { currentUser, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/">DarkWeb Dashboard</Link>
      </div>
      <div className="navbar-links">
        {currentUser && (
          <>
            <Link to="/data-analysis">Data Analysis</Link>
            {currentUser.isAdmin && <Link to="/user-management">Users</Link>}
            <Link to="/settings">Settings</Link>
            <button onClick={handleLogout} className="logout-button">
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;