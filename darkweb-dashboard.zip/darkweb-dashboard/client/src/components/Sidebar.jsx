import React from 'react';
import { NavLink } from 'react-router-dom';
import { FaHome, FaChartLine, FaUsers, FaCog, FaDatabase } from 'react-icons/fa';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <h2>DW Dashboard</h2>
      </div>
      
      <nav className="sidebar-nav">
        <ul className="sidebar-menu">
          <li className="sidebar-item">
            <NavLink 
              to="/" 
              exact 
              className="sidebar-link" 
              activeClassName="active"
            >
              <FaHome className="sidebar-icon" />
              <span className="sidebar-text">Dashboard</span>
            </NavLink>
          </li>
          
          <li className="sidebar-item">
            <NavLink 
              to="/data-analysis" 
              className="sidebar-link" 
              activeClassName="active"
            >
              <FaChartLine className="sidebar-icon" />
              <span className="sidebar-text">Data Analysis</span>
            </NavLink>
          </li>
          
          <li className="sidebar-item">
            <NavLink 
              to="/data-sources" 
              className="sidebar-link" 
              activeClassName="active"
            >
              <FaDatabase className="sidebar-icon" />
              <span className="sidebar-text">Data Sources</span>
            </NavLink>
          </li>
          
          <li className="sidebar-item">
            <NavLink 
              to="/user-management" 
              className="sidebar-link" 
              activeClassName="active"
            >
              <FaUsers className="sidebar-icon" />
              <span className="sidebar-text">User Management</span>
            </NavLink>
          </li>
          
          <li className="sidebar-item">
            <NavLink 
              to="/settings" 
              className="sidebar-link" 
              activeClassName="active"
            >
              <FaCog className="sidebar-icon" />
              <span className="sidebar-text">Settings</span>
            </NavLink>
          </li>
        </ul>
      </nav>
      
      <div className="sidebar-footer">
        <div className="user-profile">
          <div className="user-avatar">JD</div>
          <div className="user-info">
            <span className="user-name">John Doe</span>
            <span className="user-role">Admin</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;