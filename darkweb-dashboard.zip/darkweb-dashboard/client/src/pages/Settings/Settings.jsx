import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import SecuritySettings from './components/SecuritySettings';
import ProfileSettings from './components/ProfileSettings';
import NotificationSettings from './components/NotificationSettings';
import './Settings.css';

const Settings = () => {
  const { currentUser, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState('');

  const handleUpdateProfile = async (updates) => {
    try {
      const res = await axios.patch('/api/users/me', updates, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setSuccessMessage('Profile updated successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
      return res.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update profile');
      throw err;
    }
  };

  const handlePasswordChange = async (passwords) => {
    try {
      await axios.patch('/api/users/me/password', passwords, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setSuccessMessage('Password changed successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to change password');
      throw err;
    }
  };

  return (
    <div className="settings-container">
      <h1>Settings</h1>
      
      {successMessage && <div className="success-message">{successMessage}</div>}
      {error && <div className="error-message">{error}</div>}

      <div className="settings-tabs">
        <button
          className={`tab-btn ${activeTab === 'profile' ? 'active' : ''}`}
          onClick={() => setActiveTab('profile')}
        >
          Profile
        </button>
        <button
          className={`tab-btn ${activeTab === 'security' ? 'active' : ''}`}
          onClick={() => setActiveTab('security')}
        >
          Security
        </button>
        <button
          className={`tab-btn ${activeTab === 'notifications' ? 'active' : ''}`}
          onClick={() => setActiveTab('notifications')}
        >
          Notifications
        </button>
      </div>

      <div className="settings-content">
        {activeTab === 'profile' && (
          <ProfileSettings 
            user={currentUser} 
            onUpdate={handleUpdateProfile} 
          />
        )}
        
        {activeTab === 'security' && (
          <SecuritySettings 
            onChangePassword={handlePasswordChange}
            onLogout={logout}
          />
        )}
        
        {activeTab === 'notifications' && (
          <NotificationSettings 
            user={currentUser}
            onUpdate={handleUpdateProfile}
          />
        )}
      </div>
    </div>
  );
};

export default Settings;