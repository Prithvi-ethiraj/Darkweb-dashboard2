import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import UserTable from './components/UserTable';
import CreateUserModal from './components/CreateUserModal';
import './UserManagement.css';

const UserManagement = () => {
  const { currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await axios.get('/api/users', {
          headers: { Authorization: `Bearer ${currentUser.token}` }
        });
        setUsers(res.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch users');
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [currentUser]);

  const handleCreateUser = async (userData) => {
    try {
      const res = await axios.post('/api/users', userData, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setUsers([...users, res.data]);
      setShowCreateModal(false);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create user');
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      await axios.delete(`/api/users/${userId}`, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setUsers(users.filter(user => user._id !== userId));
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete user');
    }
  };

  const handleUpdateUser = async (userId, updates) => {
    try {
      const res = await axios.patch(`/api/users/${userId}`, updates, {
        headers: { Authorization: `Bearer ${currentUser.token}` }
      });
      setUsers(users.map(user => user._id === userId ? res.data : user));
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update user');
    }
  };

  return (
    <div className="user-management">
      <div className="header">
        <h1>User Management</h1>
        <button 
          className="create-user-btn"
          onClick={() => setShowCreateModal(true)}
        >
          + Create User
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {loading ? (
        <div className="loading-spinner"></div>
      ) : (
        <UserTable 
          users={users} 
          currentUserId={currentUser._id}
          onDelete={handleDeleteUser}
          onUpdate={handleUpdateUser}
        />
      )}

      <CreateUserModal
        show={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={handleCreateUser}
      />
    </div>
  );
};

export default UserManagement;