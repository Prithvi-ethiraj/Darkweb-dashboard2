import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor for adding auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for handling errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('token');
      window.location = '/login';
    }
    return Promise.reject(error);
  }
);

export default {
  // Auth endpoints
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  getCurrentUser: () => api.get('/auth/me'),

  // User endpoints
  getUsers: () => api.get('/users'),
  createUser: (userData) => api.post('/users', userData),
  updateUser: (userId, updates) => api.patch(`/users/${userId}`, updates),
  deleteUser: (userId) => api.delete(`/users/${userId}`),

  // Data endpoints
  getDataSources: () => api.get('/data-sources'),
  createDataSource: (data) => api.post('/data-sources', data),
  testDataSource: (id) => api.post(`/data-sources/${id}/test`),
  deleteDataSource: (id) => api.delete(`/data-sources/${id}`),

  // Report endpoints
  getReports: () => api.get('/reports'),
  generateReport: (data) => api.post('/reports/generate', data),
  downloadReport: (id) => api.get(`/reports/${id}/download`, { responseType: 'blob' }),
  deleteReport: (id) => api.delete(`/reports/${id}`),

  // Settings endpoints
  updateProfile: (data) => api.patch('/users/me', data),
  changePassword: (data) => api.patch('/users/me/password', data),
  updateNotifications: (data) => api.patch('/users/me/notifications', data)
};