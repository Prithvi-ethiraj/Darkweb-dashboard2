const mongoose = require('mongoose');

const dataSourceSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'User'
  },
  name: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['MySQL', 'PostgreSQL', 'MongoDB', 'API', 'CSV']
  },
  host: {
    type: String,
    required: true
  },
  port: {
    type: Number
  },
  database: {
    type: String
  },
  username: {
    type: String
  },
  password: {
    type: String
  },
  options: {
    type: Object
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('DataSource', dataSourceSchema);