const express = require('express');
const router = express.Router();
const DataSource = require('../models/DataSource');
const { verifyToken } = require('../middleware/auth');

// Get all data sources
router.get('/', verifyToken, async (req, res) => {
  try {
    const dataSources = await DataSource.find({ userId: req.user.id });
    res.json(dataSources);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add new data source
router.post('/', verifyToken, async (req, res) => {
  const dataSource = new DataSource({
    userId: req.user.id,
    name: req.body.name,
    type: req.body.type,
    host: req.body.host,
    port: req.body.port,
    database: req.body.database,
    username: req.body.username,
    // Note: In production, you should encrypt the password
    password: req.body.password,
    options: req.body.options
  });

  try {
    const newDataSource = await dataSource.save();
    res.status(201).json(newDataSource);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete data source
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const dataSource = await DataSource.findOne({ 
      _id: req.params.id,
      userId: req.user.id
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }

    await dataSource.remove();
    res.json({ message: 'Data source deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;