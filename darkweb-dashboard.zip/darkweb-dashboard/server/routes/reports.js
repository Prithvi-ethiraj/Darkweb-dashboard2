const express = require('express');
const router = express.Router();
const Report = require('../models/Report');
const { verifyToken } = require('../middleware/auth');
const mongoose = require('mongoose');

// Get all reports
router.get('/', verifyToken, async (req, res) => {
  try {
    const reports = await Report.find({ userId: req.user.id })
      .sort({ createdAt: -1 });
    res.json(reports);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Generate new report
router.post('/generate', verifyToken, async (req, res) => {
  try {
    const report = new Report({
      userId: req.user.id,
      name: req.body.name,
      type: req.body.type,
      parameters: req.body.parameters
    });

    const newReport = await report.save();
    
    // Simulate async report generation
    setTimeout(async () => {
      try {
        newReport.status = 'completed';
        newReport.content = {
          summary: `Generated ${newReport.type} report`,
          data: {
            recordsProcessed: Math.floor(Math.random() * 1000),
            generatedAt: new Date()
          }
        };
        await newReport.save();
      } catch (err) {
        console.error('Report completion error:', err);
      }
    }, 2000);

    res.status(201).json(newReport);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
module.exports = mongoose.model('Report', ReportSchema);